def download_video(url):
    # Logic to download video using a library like pytube or youtube_dl
    video_info = {
        'title': 'Example Video Title',
        'download_link': 'http://example.com/download'
    }
    return video_info
